package practica1;

public class YaExisteException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public YaExisteException(String mensaje){
		super();
	}

}
