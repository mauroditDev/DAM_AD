package practica1;

import java.io.File;

public class borrar {

	public static void main(String[] args) {
		File f = new File(".");
		System.out.println(f.getAbsolutePath());

	}

}
